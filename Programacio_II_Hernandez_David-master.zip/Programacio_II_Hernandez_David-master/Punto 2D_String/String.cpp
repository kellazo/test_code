#include "String.h"
#include <stdio.h>

cString::cString()
{
	Alloc(1);
	strcpy_s(myString, size, "");
}

cString::cString(const cString& cRecieved)
{
	Alloc(cRecieved.Len() + 1);
	strcpy_s(myString, size, cRecieved.GetString());
}

cString::cString(const char* format, ...)
{
	size = 0;

	if (format != NULL)
	{
		static char tmp[TMP_STRING_SIZE];
		static va_list ap;

		//Construir la myString a partir dels arguments variables
		va_start(ap, format);
		int res = vsprintf_s(tmp, TMP_STRING_SIZE, format, ap);
		va_end(ap);

		if (res > 0)
		{
			Alloc(res + 1);
			strcpy_s(myString, size, tmp);
		}
	}
	if (size == 0)
	{
		Alloc(1);
		Clear();
	}
}

//////////////
//Destructor//
//////////////

cString::~cString()
{
	if (myString)
	{
		delete[] myString;
	}
}

///////////
//M�todes//
//////////

void cString::Alloc(int res)
{
	size = res;
	myString = new char[size];
}

void cString::Clear()
{
	if (myString != NULL)
	{
		delete[] myString;
		Alloc(1);
		strcpy_s(myString, size, "");
	}
}

unsigned int cString::Len() const
{
	return strlen(myString);
}

int cString::Capacity() const
{
	return size;
}

const char* cString::GetString() const
{
	return myString;
}




/////////////
//Operadors//
/////////////

bool cString::operator== (const cString& string) const
{
	return strcmp(string.myString, myString) == 0;
}

bool cString::operator== (const char* string) const
{
	if (string != NULL)
	{
		return strcmp(string, myString) == 0;
	}
	return false;
}

bool cString::operator!= (const cString& string) const
{
	return strcmp(string.myString, myString) != 0;
}

bool cString::operator!= (const char* string) const
{
	if (string != NULL)
	{
		return strcmp(string, myString) != 0;
	}
	return false;
}


cString cString::operator= (const char* string)
{
	if (string != NULL)
	{
		if (strlen(string) + 1 > size)
		{
			delete[] myString;
			Alloc(strlen(string) + 1);	
		}
		strcpy_s(myString, size, string);
	}
	else
	{
		Clear();
	}
	return(*this);
}

cString cString::operator= (const cString& string)
{
	if (string.myString != NULL)
	{
		if (string.Len() + 1 > size)
		{
			delete[] myString;
			Alloc(string.Len() + 1);
		}
		strcpy_s(myString, size, string.myString);
	}
	else
	{
		Clear();
	}

	return(*this);
}

const cString cString::operator+= (const char* string)
{
	if (string != NULL)
	{
		cString tmp(*this);
		delete[] myString;
		Alloc(strlen(string) + size);
		strcpy_s(myString, tmp.size, tmp.myString);
		strcat_s(myString, size, string);
	}
	return(*this);
}

const cString cString::operator+= (const cString& string)
{
	if (string.myString != NULL)
	{
		cString tmp(*this);
		delete[] myString;
		Alloc(strlen(string.myString) + size);
		strcpy_s(myString, tmp.size, tmp.myString);
		strcat_s(myString, size, string.myString);
	}
	return(*this);
}

