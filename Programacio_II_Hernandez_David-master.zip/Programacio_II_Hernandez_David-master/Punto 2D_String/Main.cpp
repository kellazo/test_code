#include <stdio.h>
#include <assert.h>


#include "FuncionesSinClasificar.h"
#include "Point2D.h"
#include "Log.h"
#include "String.h"
#include "SLinkedList.h"
#include "DLinkedList.h"
#include "FuncionesSinClasificar.h"
#include "DinamicArray.h"
#include "Stack.h"
#include "Queue.h"
#include "Tree.h"



int main()
{
	cTree<char> Arbolito;
	
	TreeNode<char>* puntero;
	TreeNode<char>* punteroBis;
	puntero = Arbolito.Add('F');
	punteroBis = Arbolito.Add('B', puntero);
	puntero = Arbolito.Add('G', puntero);
	puntero = Arbolito.Add('H', puntero);
	puntero = Arbolito.Add('I', puntero);

	Arbolito.Add('A', punteroBis);
	punteroBis = Arbolito.Add('D', punteroBis);
	
	Arbolito.Add('C', punteroBis);
	Arbolito.Add('E', punteroBis);

	cDList<char> lista;

	Arbolito.VisitInOrder_Rec(&lista);

	int nList = lista.Count();

	printf("InOrder_Rec:\n");
	for (int n = 0; n < nList; n++)
	{
		printf(", %c", lista.Get(n)->value);
	}
	printf("\n");


	lista.Clear();

	
	Arbolito.VisitInOrder(&lista);

	nList = lista.Count();

	printf("\nInOrder:\n");
	for (int n = 0; n < nList; n++)
	{
		printf(", %c", lista.Get(n)->value);
	}
	printf("\n");
	
	system("pause");
}