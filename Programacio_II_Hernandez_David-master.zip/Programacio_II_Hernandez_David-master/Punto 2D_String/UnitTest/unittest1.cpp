#include "stdafx.h"
#include "CppUnitTest.h"
#include "../DinamicArray.h"
#include "../Point2D.h"
#include "../Point2D.cpp"
#include "../String.h"
#include "../String.cpp"
#include "../DLinkedList.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest
{		
	TEST_CLASS(UnitTest_Ricard)
	{
	public:

		// cString -----------------------------------------
		TEST_METHOD(SString_empty_ctor)
		{
			cString s;
			Assert::AreEqual((int)s.Len(), 0);
		}
		TEST_METHOD(SString_char_ctor)
		{
			cString s("Hola mundo");
			Assert::AreEqual((int)s.Len(), 10);
		}
		TEST_METHOD(SString_format_ctor)
		{
			cString s("%s %s %d", "hola", "mundo", 12);
			Assert::AreEqual((int)s.Len(), 13);
		}
		TEST_METHOD(SString_copy_ctor)
		{
			cString s("%s %s %d", "hola", "mundo", 12);
			cString s2(s);
			Assert::AreEqual((int)s2.Len(), 13);
		}
		TEST_METHOD(SString_op_equal)
		{
			cString s1("Hola mundo");
			cString s2("Hola mundo");
			Assert::IsTrue(s1 == s2);
		}
		TEST_METHOD(SString_op_notequal)
		{
			cString s1("Hola mundo 1");
			cString s2("Hola mundo 2");
			Assert::IsTrue(s1 != s2);
		}
		TEST_METHOD(SString_op_equal_cstr)
		{
			cString s1("Hola mundo");
			Assert::IsTrue(s1 == "Hola mundo");
		}
		TEST_METHOD(SString_op_notequal_cstr)
		{
			cString s1("Hola mundo 1");
			Assert::IsTrue(s1 != "test");
		}
		TEST_METHOD(SString_op_assign)
		{
			cString s1("Hola mundo");
			cString s2;
			s2 = s1;
			Assert::IsTrue(s2 == "Hola mundo");
		}
		TEST_METHOD(SString_op_assign_cstr)
		{
			cString s1("Hola mundo");
			s1 = "this is a test";
			Assert::IsTrue(s1 == "this is a test");
		}
		TEST_METHOD(SString_op_concat)
		{
			cString s1("Hola mundo");
			cString s2("this is a test");
			s1 += s2;
			Assert::IsTrue(s1 == "Hola mundothis is a test");
		}
		TEST_METHOD(SString_op_concat_cstr)
		{
			cString s1("Hola mundo");
			s1 += "this is a test";
			Assert::IsTrue(s1 == "Hola mundothis is a test");
		}
		TEST_METHOD(SString_length)
		{
			cString s1("Hola mundo");
			Assert::AreEqual((int)s1.Len(), 10);
		}
		TEST_METHOD(SString_capacity)
		{
			cString s1("Hola mundo");
			Assert::AreEqual((int)s1.Capacity(), 11);
		}
		TEST_METHOD(SString_getstr)
		{
			cString s1("Hola mundo");
			Assert::AreEqual((int)strcmp("Hola mundo", s1.GetString()), 0);
		}
		TEST_METHOD(SString_clear)
		{
			cString s1("Hola mundo");
			s1.Clear();
			Assert::AreEqual((int)s1.Len(), 0);
		}

		// cDList --------------------------------------------
		TEST_METHOD(ListAdd)
		{
			cDList<int> mylist;
			mylist.Add(6);
			mylist.Add(10);
			mylist.Add(15);
			Assert::IsTrue(mylist.GetFirst()->value == 6 && mylist.Get(1)->value == 10 && mylist.GetLast()->value == 15);
		}

		TEST_METHOD(ListDel)
		{
			cDList<int> mylist;
			mylist.Add(5);
			Assert::IsTrue(mylist.Del(mylist.GetFirst()));
			Assert::AreEqual((int)mylist.Count(), 0);
		}

		TEST_METHOD(ListClear)
		{
			cDList<int> mylist;
			mylist.Add(1);
			mylist.Add(2);
			mylist.Add(3);
			mylist.Clear();
			Assert::AreEqual((int)mylist.Count(), 0);
		}
	};
}