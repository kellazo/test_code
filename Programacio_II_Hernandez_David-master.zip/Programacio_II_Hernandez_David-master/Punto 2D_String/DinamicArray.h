#include <stdio.h>
#include <assert.h>
#include "Log.h"
#include "FuncionesSinClasificar.h"

template <class TYPE>
class cDynArray
{
private:
	unsigned int numElements;
	unsigned int allocatedMemory;
	TYPE* data;

public:
	cDynArray(){ data = NULL; numElements = 0; numElements = 0; }

	cDynArray(const int MemorySize) { data = new TYPE[MemorySize]; allocatedMemory = MemorySize; numElements = 0; }

	~cDynArray()
	{
		if (data != NULL) { delete data; }
	}

	const unsigned int GetCapacity() const
	{
		return allocatedMemory;
	}

	const unsigned int Count() const
	{
		return numElements;
	}

	bool Shrink()
	{
		if (numElements < allocatedMemory)
		{
			Reallocate(numElements);
			return true;
		}
		return false;
	}

	void Reallocate(const int newSize)
	{
		TYPE* newData = new TYPE[newSize];
		allocatedMemory = newSize;
		if (data != NULL)
		{
			for (int n = 0; n <= MIN(newSize, numElements); n++)
			{
				newData[n] = data[n];
			}

			delete data;
		}
		data = newData;
		numElements = MIN(newSize, numElements);
	}

	void Push(const TYPE value)
	{
		if (numElements + 1 > allocatedMemory)
		{
			Reallocate(allocatedMemory + 1);
		}
		data[numElements] = value;
		numElements++;
	}

	bool Pop()
	{
		if (numElements >= 1)
		{
			numElements--;
			return true;
		}
		return false;

	}

	void Clear()
	{
		numElements = 0;
	}

	void Insert(const TYPE value, const int pos)
	{
		if (pos < allocatedMemory)
		{
			if (numElements + 1 > allocatedMemory)
			{
				Reallocate(allocatedMemory + 1);
			}
			for (int n = numElements; n > pos; n--)
			{
				data[n] = data[n - 1];
			}
			data[pos] = value;
			numElements++;
		}
		else
		{
			LOG("\n\nSe intent� insertar un valor fuera de la memoria en un DynArray\n\n");
		}
	}

	TYPE& operator[] (const unsigned int index)
	{
		if (index < numElements)
		{
			return data[index];
		}
		else
		{
			assert(false);
		}
	}

	const TYPE& operator[] (const unsigned int index) const
	{
		if (index < numElements)
		{
			return data[index];
		}
		else
		{
			assert(false);
		}
	}

	TYPE* At(unsigned int index)
	{
		TYPE* result = NULL;

		if (index < numElements)
			result = &data[index];

		return result;
	}

	const TYPE* At(unsigned int index) const
	{
		TYPE* result = NULL;

		if (index < numElements)
			result = &data[index];

		return result;
	}

};
